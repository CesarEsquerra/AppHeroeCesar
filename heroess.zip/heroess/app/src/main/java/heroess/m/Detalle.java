package heroess.m;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class Detalle extends AppCompatActivity {

    ImageView fotoDetalle;
    TextView ful_name,power,byograpy_aparicion,raza,ocupacion,conections;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        fotoDetalle = findViewById(R.id.imageVPersonaje);
        ful_name =findViewById(R.id.txtVName);
        power =findViewById(R.id.txtVpowerstats);
        byograpy_aparicion = findViewById(R.id.txtVbiography);
        raza = findViewById(R.id.txtVappearance);
        ocupacion = findViewById(R.id.txtVwork);
        conections =findViewById(R.id.txtVconnections);

        recibirDatosHeroe();


    }

    private void recibirDatosHeroe() {
        Bundle extras = getIntent().getExtras();
        String url_Image =extras.getString("imagen_uri");
        Picasso.get().load(url_Image).into(fotoDetalle);
        ful_name.setText(extras.getString("hero_fulname_name"));
        power.setText("-Power: "+extras.getString("hero_power"));
        byograpy_aparicion.setText("-Primera aparicion: "+extras.getString("hero_byograpy_aparicion"));
        raza.setText("-Race: "+extras.getString("hero_race"));
        ocupacion.setText("-Work: " +extras.getString("hero_work"));
        conections.setText("-Conections: "+extras.getString("hero_conections"));
    }


}