package heroess.m;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import heroess.m.Adapter.AdapterHeroe;
import heroess.m.Modelo.M_Heroe;
import heroess.m.RequestApi.JsonPlaceHolderApi;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<M_Heroe> heroes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

       getPosts();

    }

    private void getPosts(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://cdn.rawgit.com/akabab/superhero-api/0.2.0/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        JsonPlaceHolderApi jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);
        Call<List<M_Heroe>> call = jsonPlaceHolderApi.getPosts();
        call.enqueue(new Callback<List<M_Heroe>>() {

                         @Override
                         public void onResponse(Call<List<M_Heroe>> call, Response<List<M_Heroe>> response) {
                             if(!response.isSuccessful()){
                                 Toast.makeText(getApplicationContext(),"casijalando",Toast.LENGTH_LONG).show();
                             }
                             Toast.makeText(getApplicationContext(),"jalando",Toast.LENGTH_LONG).show();
                              heroes = response.body();

                           final AdapterHeroe nAdapterH = new AdapterHeroe(getApplicationContext(),heroes);
                           nAdapterH.setOnClickListener(new View.OnClickListener() {
                               @Override
                               public void onClick(View view) {
                                    Toast.makeText(getApplicationContext(),""+heroes.get(recyclerView.getChildAdapterPosition(view)).getName(),Toast.LENGTH_LONG).show();
                                   Intent myInten = new Intent(getApplicationContext(), Detalle.class);
                                   int p = recyclerView.getChildAdapterPosition(view);

                                   myInten.putExtra("imagen_uri", heroes.get(p).getImages().getLg());
                                   myInten.putExtra("hero_fulname_name", heroes.get(p).getBiography().getFullName());
                                   myInten.putExtra("hero_power",heroes.get(p).getPowerstats().getPower()+ "\n-Combat: "+ heroes.get(p).getPowerstats().getCombat());
                                   myInten.putExtra("hero_byograpy_aparicion",heroes.get(p).getBiography().getFirstAppearance());
                                   myInten.putExtra("hero_race",heroes.get(p).getAppearance().getRace());
                                   myInten.putExtra("hero_work",heroes.get(p).getWork().getOccupation());
                                   myInten.putExtra("hero_conections",heroes.get(p).getConnections().getGroupAffiliation() +"\n\n-Relatives: "+ heroes.get(p).getConnections().getRelatives());
                                   startActivity(myInten);
                                   //notifyDataSetChanged();
                               }
                           });
                             recyclerView.setAdapter(nAdapterH);

                         }

                         @Override
                         public void onFailure(Call<List<M_Heroe>> call, Throwable t) {
                             Toast.makeText(getApplicationContext(),"nojalotadavia",Toast.LENGTH_LONG).show();
                         }
                         });


        /* GRACIAS POR VER EL COIGO  {
  private void getUnhereo(int id) {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://www.superheroapi.com/api.php/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        JsonPlaceHolderApi jSonApi = retrofit.create(JsonPlaceHolderApi.class);
        Call<M_Heroe> call = jSonApi.getHeroe(id);
        call.enqueue(new Callback<M_Heroe>() {
            @Override
            public void onResponse(Call<M_Heroe> call, Response<M_Heroe> response) {
                if(!response.isSuccessful()){

                    Toast.makeText(getApplicationContext(),"casijalandr",Toast.LENGTH_LONG).show();
                    //return;
                }
                Toast.makeText(getApplicationContext(),"jalando",Toast.LENGTH_LONG).show();

                recyclerView.setAdapter(new AdapterHeroe(getApplicationContext()));



            }

            @Override
            public void onFailure(Call<M_Heroe> call, Throwable t) {
                Toast.makeText(getApplicationContext(),"nojalotadavia",Toast.LENGTH_LONG).show();

            }
        });

    }


            @Override
            public void onResponse(Call<List<M_Heroe>>call, Response<List<M_Heroe>> response) {

                if(!response.isSuccessful()){

                  mJsonTxtView.setText("Codigo: "+response.code());
                    return;
                }
                String heroeString = response.body().toString();

                //heroes = getPosts(response.body());
                heroes = response.body();
                recyclerView.setAdapter(new AdapterHeroe(getApplicationContext(),heroes));

                }


            }

            @Override
            public void onFailure(Call<List<M_Heroe>> call, Throwable t) {
                mJsonTxtView.setText(t.getMessage());

            }
        }); */

    }
}