package heroess.m.RequestApi;


import java.util.List;

import heroess.m.Modelo.M_Heroe;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface JsonPlaceHolderApi {

    @GET("all.json")
    Call<List<M_Heroe>> getPosts();

    @GET("316862649718407/{id}")
    Call<M_Heroe> getHeroe(@Path("id") int id);
}