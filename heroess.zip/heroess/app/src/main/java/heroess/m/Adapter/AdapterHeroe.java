package heroess.m.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import heroess.m.Detalle;
import heroess.m.Modelo.M_Heroe;
import heroess.m.R;

public class AdapterHeroe extends RecyclerView.Adapter<AdapterHeroe.MyViewHolder> implements View.OnClickListener{

    private Context mContext;
    private List<M_Heroe> heroeList = new ArrayList<>();
    private View.OnClickListener listener;

    public AdapterHeroe(Context mContext, List<M_Heroe> heroeList) {
        this.mContext = mContext;
        this.heroeList = heroeList;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.heroe_card,parent,false);

        view.setOnClickListener(this);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder,int position) {

    M_Heroe heroe = heroeList.get(position);
    holder.nombre.setText(heroe.getName());
     Picasso.get().load(heroe.getImages().getLg()).into(holder.fotoHeroe);
         // .load(heroe.getImage().getUrl())


    }
    @Override
    public int getItemCount() {
        return heroeList.size();
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;

    }

    @Override
    public void onClick(View view) {
        if (listener!=null){
            listener.onClick(view);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView nombre;
        ImageView fotoHeroe;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = (TextView) itemView.findViewById(R.id.title);
            fotoHeroe = (ImageView) itemView.findViewById(R.id.thumbnail);

/*            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();

                    M_Heroe heroeClick = heroeList.get(position);
                    Toast.makeText(mContext,"click"+heroeList.get(position).getPowerstats().getCombat(),Toast.LENGTH_LONG).show();
                    Intent myInten = new Intent(mContext, Detalle.class);
                    myInten.putExtra("imagen_uri", heroeClick.getImages().getLg());
                    myInten.putExtra("hero_fulname_name", heroeClick.getBiography().getFullName());
                    myInten.putExtra("hero_power",heroeClick.getPowerstats().getPower());
                    myInten.putExtra("hero_byograpy_aparicion",heroeClick.getBiography().getFirstAppearance());
                    myInten.putExtra("hero_race",heroeClick.getAppearance().getRace());
                    myInten.putExtra("hero_work",heroeClick.getWork().getOccupation());
                    myInten.putExtra("hero_conections",heroeClick.getConnections().toString());
                    mContext.startActivity(myInten);
                    notifyDataSetChanged();

                }
            });*/

        }

    }


}
